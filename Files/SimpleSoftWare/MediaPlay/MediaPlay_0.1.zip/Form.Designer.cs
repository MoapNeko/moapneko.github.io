﻿
namespace MusicPlay
{
    partial class Form
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form));
            this.axWindowsMediaPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.BtnAddFile = new System.Windows.Forms.Button();
            this.ListBox_SongsList = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // axWindowsMediaPlayer
            // 
            this.axWindowsMediaPlayer.Enabled = true;
            this.axWindowsMediaPlayer.Location = new System.Drawing.Point(11, 10);
            this.axWindowsMediaPlayer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.axWindowsMediaPlayer.Name = "axWindowsMediaPlayer";
            this.axWindowsMediaPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer.OcxState")));
            this.axWindowsMediaPlayer.Size = new System.Drawing.Size(606, 338);
            this.axWindowsMediaPlayer.TabIndex = 0;
            // 
            // BtnAddFile
            // 
            this.BtnAddFile.Location = new System.Drawing.Point(15, 450);
            this.BtnAddFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnAddFile.Name = "BtnAddFile";
            this.BtnAddFile.Size = new System.Drawing.Size(111, 39);
            this.BtnAddFile.TabIndex = 2;
            this.BtnAddFile.Text = "添加文件";
            this.BtnAddFile.UseVisualStyleBackColor = true;
            this.BtnAddFile.Click += new System.EventHandler(this.BtnAddFile_Click);
            // 
            // ListBox_SongsList
            // 
            this.ListBox_SongsList.FormattingEnabled = true;
            this.ListBox_SongsList.ItemHeight = 15;
            this.ListBox_SongsList.Location = new System.Drawing.Point(836, 12);
            this.ListBox_SongsList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ListBox_SongsList.Name = "ListBox_SongsList";
            this.ListBox_SongsList.Size = new System.Drawing.Size(132, 424);
            this.ListBox_SongsList.TabIndex = 7;
            this.ListBox_SongsList.DoubleClick += new System.EventHandler(this.ListBox_SongsList_DoubleClick);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 501);
            this.Controls.Add(this.ListBox_SongsList);
            this.Controls.Add(this.BtnAddFile);
            this.Controls.Add(this.axWindowsMediaPlayer);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form";
            this.Text = "媒体播放器";
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer;
        private System.Windows.Forms.Button BtnAddFile;
        private System.Windows.Forms.ListBox ListBox_SongsList;
    }
}

