﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using WMPLib;

namespace MusicPlay
{
    public partial class Form : System.Windows.Forms.Form
    {
        OpenFileDialog ofd = new OpenFileDialog();
        List<string> songs = new List<string>();
        public Form()
        { 
            InitializeComponent();
        }

        private void BtnAddFile_Click(object sender, EventArgs e)
        {
            ListBox_SongsList.Items.Clear();//每次点击添加文件时清除listbox里的内容
            ofd.Title = "选择媒体文件";
            ofd.Multiselect = true;//是否允许多选
            ofd.InitialDirectory = @"D:\Music";
            ofd.Filter = @"媒体文件|*.mp3||*.mp4";//选择的文件限制
            ofd.ShowDialog();
            string[] filePath = ofd.FileNames;
            for (int i = 0; i < filePath.Length; i++) {
                ListBox_SongsList.Items.Add(Path.GetFileName(filePath[i]));
                songs.Add(filePath[i]);
            }
        }
        private void ListBox_SongsList_DoubleClick(object sender, EventArgs e) {
            /*
            AxWMPLib.AxWindowsMediaPlayer item = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(item)).BeginInit();//对象初始化
            this.Controls.Add(item);
            ((System.ComponentModel.ISupportInitialize)(item)).EndInit();//结束初始化
            */
            //上面这部分如果你是要创建一个媒体播放控件的话，新创建的对象要实例化
            if (songs.Count != 0) {
                axWindowsMediaPlayer.URL = songs[ListBox_SongsList.SelectedIndex];
                axWindowsMediaPlayer.Ctlcontrols.play();
            }
            
        }
    }
}
